package com.eugene.listviewexample;

public class Log {
    private String item;

    public String getItem() {
        return this.item;
    }

    public void setItem(String strItem) {
        this.item = strItem;
    }
}
