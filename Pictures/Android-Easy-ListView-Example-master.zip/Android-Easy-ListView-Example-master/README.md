# ListView-Example
Dynamically add and remove items from listview

Simple example of adding items with an EditText & Button and removing items with a context menu. 

List item quick press = Toast
List item long press = context menu
